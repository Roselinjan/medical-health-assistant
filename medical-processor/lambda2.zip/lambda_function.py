import json
import boto3
import urllib.parse
import io
import PyPDF2
import re



s3_client = boto3.client('s3') 

textract_client = boto3.client('textract')  

NORMAL_RANGES = {
    # blood count
    'hemoglobin': {
        'min': 12.0, 'max': 17.5,
        'unit': 'g/dL', 'display_name': 'Hemoglobin'
    },
    'wbc': {
        'min': 4000, 'max': 11000,
        'unit': '/cmm', 'display_name': 'WBC Count'
    },
    'platelet': {
        'min': 150000, 'max': 400000,
        'unit': '/cmm', 'display_name': 'Platelet Count'
    },
    'rbc': {
        'min': 3.5, 'max': 5.5,
        'unit': 'million/cmm', 'display_name': 'RBC Count'
    },
    'mcv': {
        'min': 80, 'max': 100,
        'unit': 'fL', 'display_name': 'MCV'
    },
    'mchc': {
        'min': 31.5, 'max': 36.0,
        'unit': 'g/dL', 'display_name': 'MCHC'
    },
    # diabetes
    'fasting blood sugar': {
        'min': 70, 'max': 100,
        'unit': 'mg/dL', 'display_name': 'Fasting Blood Sugar'
    },
    'blood sugar pp': {
        'min': 70, 'max': 140,
        'unit': 'mg/dL', 'display_name': 'Post Prandial Blood Sugar'
    },
    'hba1c': {
        'min': 4.0, 'max': 5.7,
        'unit': '%', 'display_name': 'HbA1c'
    },
    # liver
    'sgpt': {
        'min': 7, 'max': 56,
        'unit': 'U/L', 'display_name': 'SGPT (Liver)'
    },
    'sgot': {
        'min': 10, 'max': 40,
        'unit': 'U/L', 'display_name': 'SGOT (Liver)'
    },
    # kidney
    'creatinine': {
        'min': 0.6, 'max': 1.2,
        'unit': 'mg/dL', 'display_name': 'Creatinine (Kidney)'
    },
    # thyroid
    'tsh': {
        'min': 0.4, 'max': 4.0,
        'unit': 'mIU/L', 'display_name': 'TSH (Thyroid)'
    }
}


def extract_with_textract(bucket, key, pdf_bytes=None):
    if pdf_bytes:
        response = textract_client.detect_document_text(
            Document={'Bytes': pdf_bytes}
        )
    else:
        response = textract_client.detect_document_text(
            Document={
                'S3Object': {
                    'Bucket': bucket,
                    'Name': key
                }
            }
        )
    
    extracted_text = ''
    for block in response['Blocks']:
        if block['BlockType'] == 'LINE':
            extracted_text += block['Text'] + '\n'
    
    return extracted_text
    # extract text from Textract response
    extracted_text = ''
    for block in response['Blocks']:  
        # hint: Textract returns a list of blocks
        if block['BlockType'] == 'LINE':  
            # hint: we want LINE blocks not WORD blocks
            extracted_text += block['Text'] + '\n'
   
    return extracted_text

bedrock_client = boto3.client('bedrock-runtime', region_name='ap-south-1')

INFERENCE_PROFILE_ID = 'apac.amazon.nova-pro-v1:0'
USE_MOCK_SUMMARY = False



def summarize_with_bedrock(extracted_text, patient_id):
    prompt = f"""You are a caring medical assistant helping patients
understand their medical reports.

Patient ID: {patient_id}

Medical Report:
{extracted_text}

Please provide:
1. A brief 2-line overview
2. Key findings in simple bullet points
3. Critical values prefixed with ⚠️
4. End with: "Please consult your doctor for personalized advice"

Maximum 300 words. Use simple English, avoid medical jargon."""

    response = bedrock_client.converse(  
    
        modelId=INFERENCE_PROFILE_ID,  
        
        messages=[
            {
                "role": "user",  
                # hint: who is sending this message?
                "content": [{"text": prompt}]  
                # hint: content item key that holds the actual text
            }
        ],
        inferenceConfig={
            "maxTokens": 1500,  
            # hint: same limit as before
            "temperature": 0.3
        }
    )

    # parse response
    summary = response['output']['message']['content'][0]['text']
    

    print(f"Summary generated successfully")
    return summary

def extract_critical_values(extracted_text):
    critical_values = []
    text_lower = extracted_text.lower()

    # temporary debug — remove after testing
    print(f"Searching for hemoglobin in text...")
    hb_index = text_lower.find('hemoglobin')
    print(f"Hemoglobin found at index: {hb_index}")
    if hb_index > -1:
     print(f"Text around hemoglobin: '{text_lower[hb_index:hb_index+100]}'")


    for param, ranges in NORMAL_RANGES.items():
        pattern = rf'{param}[^\d]{{0,50}}(\d+\.?\d*)'
        match = re.search(pattern, text_lower)
        if match:
            value = float(match.group(1))
            if value < ranges['min'] or value > ranges['max']:
                critical_values.append({
                    'parameter': ranges['display_name'],
                    'value': value,
                    'unit': ranges['unit'],
                    'min': ranges['min'],
                    'max': ranges['max'],
                    'status': 'LOW' if value < ranges['min'] else 'HIGH'
                })
    return critical_values


def lambda_handler(event, context):
    try:
        # 1. Extract bucket and key from S3 event
        bucket = event['Records'][0]['s3']['bucket']['name']  
        
       
        key = urllib.parse.unquote_plus(
            event['Records'][0]['s3']['object']['key']
        )
        

        # 2. Extract patient_id from key
        patient_id = key.split('/')[1]  
    
       
        # 3. Log what we received
        print(f"Processing file: {key}")
        print(f"Patient ID: {patient_id}")

        # 4. Fetch PDF from S3
        response = s3_client.get_object(
            Bucket=bucket,    
            Key=key        
        )

        # 5. Read PDF bytes into memory
        pdf_bytes = response['Body'].read()
        

        # 6. Create PDF reader
        pdf_reader = PyPDF2.PdfReader(io.BytesIO(pdf_bytes))
        

        # 7. Extract text from all pages
        extracted_text = ''
        for page in pdf_reader.pages:
            extracted_text += page.extract_text()

        # 8. Smart fallback to Textract
        clean_text = re.sub(r'\s+', '', extracted_text)

        # detect private font encoding (\uf000-\uf8ff range)
        has_private_unicode = any(
            '\uf000' <= char <= '\uf8ff'
            for char in extracted_text[:500]
        )

        if len(clean_text) < 100 or has_private_unicode:
            if has_private_unicode:
                print("PyPDF2 returned private font encoding — falling back to Textract")
            else:
                print("PyPDF2 returned insufficient text — falling back to Textract")
            extracted_text = extract_with_textract(bucket, key, pdf_bytes)
            print(f"Textract returned {len(extracted_text)} characters")
        else:
            print(f"PyPDF2 extraction successful — {len(clean_text)} real characters")

        # 9. Log extracted text length
        print(f"Extracted {len(extracted_text)} characters")  
        
        print(f"First 200 chars: {extracted_text[:200]}") 
        print(f"Last 200 chars: {extracted_text[200:1000]}") 

        # 10. Summarize with Bedrock
        summary = summarize_with_bedrock(extracted_text, patient_id)
        print(f"Summary generated: {summary[:200]}")

        # 11. Extract critical values
        critical_values = extract_critical_values(extracted_text)
        print(f"Critical values found: {len(critical_values)}")
        
       
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'File received successfully',
                'patient_id': patient_id,
                'key': key,
                'summary': summary,
                'critical_values': critical_values
            })
        }
       
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }